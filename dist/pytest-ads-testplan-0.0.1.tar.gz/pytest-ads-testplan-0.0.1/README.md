# pytest-ads-testplan
Pytest plugin to support Azure Test Plan updating for test cases
